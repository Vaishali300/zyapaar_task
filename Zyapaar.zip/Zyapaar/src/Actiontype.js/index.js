export const GET_USERSLIST = 'GET_USERSLIST';
export const SET_USER = 'SET_USER'